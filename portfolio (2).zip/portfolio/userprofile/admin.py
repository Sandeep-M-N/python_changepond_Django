from django.contrib import admin
from.models import Portfolio,Author,feedback,Tags
# Register your models here.
admin.site.register(Portfolio)
admin.site.register(Author)
admin.site.register(feedback)
admin.site.register(Tags)